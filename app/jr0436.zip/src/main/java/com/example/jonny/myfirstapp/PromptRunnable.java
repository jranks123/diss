package com.example.jonny.myfirstapp;

/**
 * Created by Jonny on 09/04/2015.
 */
public class PromptRunnable implements Runnable {
    private String v;
    void setValue(String inV) {
        this.v = inV;
    }
    String getValue() {
        return this.v;
    }
    public void run() {
        this.run();
    }
}